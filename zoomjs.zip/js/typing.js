var t=document.getElementById("typing");
   setTimeout(function(){t.innerHTML="_";}, 100);
   setTimeout(function(){t.innerHTML=" ‏‏‎ ";}, 400);
   setTimeout(function(){t.innerHTML="_";}, 700);
   setTimeout(function(){t.innerHTML=" ‏‏‎ ";}, 1000);
   setTimeout(function(){t.innerHTML="_";}, 1300);
   setTimeout(function(){t.innerHTML=" ‏‏‎ ";}, 1500);
   setTimeout(function(){t.innerHTML="_";}, 1800);
   setTimeout(function(){t.innerHTML=" ‏‏‎ ";}, 2100);
   setTimeout(typeOut, 1300);
  function typeOut(){
  setTimeout(function(){t.innerHTML="n_";}, 1000);
  setTimeout(function(){t.innerHTML="ne_";}, 1100);
   setTimeout(function(){t.innerHTML="new_";}, 1200);
    setTimeout(function(){t.innerHTML="new _";}, 1300);
     setTimeout(function(){t.innerHTML="new Z_";}, 1400);
         setTimeout(function(){t.innerHTML="new Zo_";}, 1500);
            setTimeout(function(){t.innerHTML="new Zoo_";}, 1600);
            setTimeout(function(){t.innerHTML="new Zoom_";}, 1700);
            setTimeout(function(){t.innerHTML="new ZoomJ_";}, 1800);
            setTimeout(function(){t.innerHTML="new ZoomJS_";}, 1900);
            setTimeout(function(){t.innerHTML="new ZoomJS(_";}, 2000);
            setTimeout(function(){t.innerHTML="new ZoomJS(m_";}, 2300);
            setTimeout(function(){t.innerHTML="new ZoomJS(me_";}, 2400);
            setTimeout(function(){t.innerHTML="new ZoomJS(mee_";}, 2500);
            setTimeout(function(){t.innerHTML="new ZoomJS(meet_";}, 2600);
             setTimeout(function(){t.innerHTML="new ZoomJS(meeti_";}, 2800);
              setTimeout(function(){t.innerHTML="new ZoomJS(meetin_";}, 2900);
               setTimeout(function(){t.innerHTML="new ZoomJS(meeting_";}, 3000);
               setTimeout(function(){t.innerHTML="new ZoomJS(meeting _";}, 3100);
               setTimeout(function(){t.innerHTML="new ZoomJS(meeting i_";}, 3300);
               setTimeout(function(){t.innerHTML="new ZoomJS(meeting id_";}, 3400);
                         setTimeout(function(){t.innerHTML="new ZoomJS(meeting id _";}, 3500);
                          setTimeout(function(){t.innerHTML="new ZoomJS(meeting id h";}, 3600);
                          setTimeout(function(){t.innerHTML="new ZoomJS(meeting id h";}, 3700);
                          setTimeout(function(){t.innerHTML="new ZoomJS(meeting id he_";}, 3800);
                          setTimeout(function(){t.innerHTML="new ZoomJS(meeting id her_";}, 3900);
                          setTimeout(function()
                          {t.innerHTML="new ZoomJS(meeting id here_";}, 4000);
                           setTimeout(function()
                          {t.innerHTML="new ZoomJS(meeting id here)_";}, 4100);
                          
                          setTimeout(function()
                          {t.innerHTML="new ZoomJS(meeting id here);_";}, 4200);

                           setTimeout(function()
                          {t.innerHTML="new ZoomJS(meeting id here); ";}, 4300);
                          setTimeout(function()
                          {t.innerHTML="new ZoomJS(meeting id here);_ ";}, 4600);
                          setTimeout(function()
                          {t.innerHTML="new ZoomJS(meeting id here); ";}, 4900);
                          setTimeout(function()
                          {t.innerHTML="new ZoomJS(meeting id here);_ ";}, 4200);
                          setTimeout(function()
                          {t.innerHTML="new ZoomJS(meeting id here); ";}, 4500);

  }